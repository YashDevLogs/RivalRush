using UnityEngine;
using Game.Core;

[RequireComponent(typeof(PowerUpController))]
public sealed class AIInputDriver : MonoBehaviour, IInputDriver
{
    public float Horizontal { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool UsePowerUpPressed { get; private set; }

    private PowerUpController powerUpController;

    [Header("Sensing")]
    [SerializeField] private float obstacleCheckDistance = 1.5f;
    [SerializeField] private LayerMask obstacleMask;

    // ✅ Cached result — written in FixedUpdate, read in Update (or wherever needed)
    private bool obstacleAhead;

    private void Awake()
    {
        powerUpController = GetComponent<PowerUpController>();
    }

    // ✅ Raycast moved to FixedUpdate — runs in sync with physics, not every render frame
    private void FixedUpdate()
    {
        obstacleAhead = Physics2D.Raycast(
            transform.position,
            Vector2.right,
            obstacleCheckDistance,
            obstacleMask
        ).collider != null;
    }

    private void Update()
    {
        Horizontal = 1f;
        JumpPressed = obstacleAhead; // reads cached result, no raycast here
        UsePowerUpPressed = ShouldUsePowerUp();
    }

    private bool ShouldUsePowerUp()
    {
        if (!powerUpController.HasPowerUp) return false;
        return Random.value > 0.97f;
    }
}
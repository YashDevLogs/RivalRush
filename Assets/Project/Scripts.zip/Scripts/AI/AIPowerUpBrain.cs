using UnityEngine;

public sealed class AIPowerUpBrain : MonoBehaviour
{
    [Header("Personality")]
    [SerializeField] private AIPersonality personality = AIPersonality.Balanced;

    private PowerUpController powerUpController;
    private AISensor sensor;
    private RaceManager raceManager;

    [Header("Race Phase")]
    [SerializeField] private float expectedRaceDuration = 30f;

    [Header("Decision Timing")]
    [SerializeField] private float minDecisionDelay = 0.4f;
    [SerializeField] private float maxDecisionDelay = 1.2f;
    [SerializeField] private float usageCooldown = 2.0f;

    private float nextDecisionTime;
    private float lastUseTime;

    // ----------------------------------------------------

    private void Awake()
    {
        powerUpController = GetComponent<PowerUpController>();
        sensor = GetComponent<AISensor>();
        raceManager = RaceManager.Instance;
    }

    // ----------------------------------------------------

    public bool ShouldUsePowerUp()
    {
        if (!powerUpController.HasPowerUp)
            return false;

        if (Time.time < nextDecisionTime)
            return false;

        if (Time.time < lastUseTime + usageCooldown)
            return false;

        float intentScore = CalculateIntentScore();

        if (Random.value < intentScore)
        {
            lastUseTime = Time.time;
            ScheduleNextDecision();
            return true;
        }

        ScheduleNextDecision();
        return false;
    }

    // ----------------------------------------------------
    // DECISION SCHEDULING
    // ----------------------------------------------------

    private void ScheduleNextDecision()
    {
        nextDecisionTime = Time.time + Random.Range(minDecisionDelay, maxDecisionDelay);
    }

    // ----------------------------------------------------
    // INTENT LOGIC
    // ----------------------------------------------------

    private float CalculateIntentScore()
    {
        float score = GetPhaseBias();
        score += GetPersonalityBias();

        // Defensive bias when in danger
        if (sensor != null && sensor.IsInDanger())
            score += GetDangerBias();

        return Mathf.Clamp01(score);
    }

    // ----------------------------------------------------
    // BIASES
    // ----------------------------------------------------

    private float GetPhaseBias()
{
    if (raceManager == null || !raceManager.CanMove())
        return 0.2f;

    float t = Mathf.Clamp01(raceManager.RaceElapsedTime / expectedRaceDuration);

    if (t < 0.3f) return 0.25f;
    if (t < 0.7f) return 0.45f;
    return 0.75f;
}

    private float GetPersonalityBias()
    {
        return personality switch
        {
            AIPersonality.Aggressive => 0.15f,
            AIPersonality.Defensive => -0.05f,
            AIPersonality.Risky => 0.25f,
            _ => 0f, // Balanced
        };
    }

    private float GetDangerBias()
    {
        return personality switch
        {
            AIPersonality.Defensive => 0.35f,
            AIPersonality.Aggressive => 0.15f,
            AIPersonality.Risky => 0.05f,
            _ => 0.2f,
        };
    }
}

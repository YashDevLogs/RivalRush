public interface IInputSource
{
    float Horizontal { get; }
    bool JumpPressed { get; }
    bool SlidePressed { get; }
    bool PowerUpPressed { get; }
}

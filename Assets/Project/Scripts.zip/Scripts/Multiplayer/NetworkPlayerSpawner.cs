using UnityEngine;
using Unity.Netcode;
using System.Collections.Generic;

public class NetworkPlayerSpawner : NetworkBehaviour
{
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private GameObject playerPrefab;

    private int nextSpawnIndex = 0;
    private List<Transform> usedSpawns = new();

    public override void OnNetworkSpawn()
    {
        if (!IsServer) return;

        Invoke(nameof(SpawnAllPlayers), 0.5f);
    }

    private void SpawnAllPlayers()
    {
        foreach (var client in NetworkManager.Singleton.ConnectedClientsList)
        {
            SpawnPlayer(client.ClientId);
        }
    }

    private void SpawnPlayer(ulong clientId)
    {
        Transform spawn = GetNextSpawn();
        GameObject player = Instantiate(playerPrefab, spawn.position, Quaternion.identity);

        player.GetComponent<NetworkObject>().SpawnAsPlayerObject(clientId);
    }

    // 🔥 NEW METHOD FOR AI
    public void SpawnAIPlayers(int count, GameObject aiPrefab)
    {
        for (int i = 0; i < count; i++)
        {
            Transform spawn = GetNextSpawn();

            GameObject ai = Instantiate(aiPrefab, spawn.position, Quaternion.identity);
            ai.GetComponent<NetworkObject>().Spawn();
        }
    }

    private Transform GetNextSpawn()
    {
        Transform spawn = spawnPoints[nextSpawnIndex % spawnPoints.Length];
        usedSpawns.Add(spawn);
        nextSpawnIndex++;
        return spawn;
    }
}
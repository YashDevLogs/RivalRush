using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

namespace Game.Systems
{
    public sealed class PlayerNetwork : NetworkBehaviour
    {
        // ── existing methods (unchanged) ────────────────────────────────

        public void SendReady(bool isReady)
        {
            Debug.Log($"[CLIENT][FLOW] SendReady CALLED | Spawned: {IsSpawned} | Owner: {IsOwner}");
            if (!CanSendOwnedRpc("Ready")) return;
            Debug.Log($"[CLIENT] Sending Ready RPC -> {isReady}");
            SetReadyServerRpc(isReady);
        }

        public void ReportSceneReady()
        {
            if (!CanSendOwnedRpc("SceneReady")) return;
            ReportSceneReadyServerRpc();
        }

        public void RequestReturnToLobby()
        {
            if (!CanSendOwnedRpc("ReturnToLobby")) return;
            RequestReturnToLobbyServerRpc();
        }

        public void LeaveLobby()
        {
            if (!CanSendOwnedRpc("LeaveLobby")) return;
            LeaveLobbyServerRpc();
        }

        // ── new: name sync ──────────────────────────────────────────────

        /// <summary>
        /// Called by LobbyUI after the lobby is ready to push the locally
        /// stored player name to the server so all clients see it.
        /// </summary>
        public void SendName(FixedString32Bytes name)
        {
            if (!CanSendOwnedRpc("SendName")) return;
            Debug.Log($"[CLIENT] Sending name RPC: {name}");
            SendNameServerRpc(name);
        }

        // ── server rpcs ─────────────────────────────────────────────────

        [ServerRpc]
        private void SetReadyServerRpc(bool isReady, ServerRpcParams rpcParams = default)
        {
            if (!TryGetLobbyManager(out var lobbyManager)) return;
            ulong clientId = rpcParams.Receive.SenderClientId;
            Debug.Log($"[SERVER] PlayerNetwork -> SetReady from {clientId}: {isReady}");
            lobbyManager.SetReady(clientId, isReady);
        }

        [ServerRpc]
        private void ReportSceneReadyServerRpc(ServerRpcParams rpcParams = default)
        {
            if (!TryGetLobbyManager(out var lobbyManager)) return;
            lobbyManager.ReportSceneReady(rpcParams.Receive.SenderClientId);
        }

        [ServerRpc]
        private void RequestReturnToLobbyServerRpc(ServerRpcParams rpcParams = default)
        {
            if (!TryGetLobbyManager(out var lobbyManager)) return;
            lobbyManager.RequestReturnToLobby(rpcParams.Receive.SenderClientId);
        }

        [ServerRpc]
        private void LeaveLobbyServerRpc(ServerRpcParams rpcParams = default)
        {
            if (!TryGetLobbyManager(out var lobbyManager)) return;
            lobbyManager.LeaveLobby(rpcParams.Receive.SenderClientId);
        }

        [ServerRpc]
        private void SendNameServerRpc(FixedString32Bytes name, ServerRpcParams rpcParams = default)
        {
            if (!TryGetLobbyManager(out var lobbyManager)) return;
            lobbyManager.UpdatePlayerName(rpcParams.Receive.SenderClientId, name);
        }

        // ── helpers ─────────────────────────────────────────────────────

        private bool CanSendOwnedRpc(string rpcName)
        {
            Debug.Log($"[CLIENT][FLOW] CanSendOwnedRpc CHECK | Spawned: {IsSpawned} | Owner: {IsOwner}");
            if (!IsSpawned)
            {
                Debug.LogError($"[CLIENT] PlayerNetwork is not spawned. Cannot send {rpcName} RPC.");
                return false;
            }

            if (!IsOwner && !IsServer)
            {
                Debug.LogError($"[CLIENT] PlayerNetwork is not owned locally. Cannot send {rpcName} RPC.");
                return false;
            }

            return true;
        }

        private bool TryGetLobbyManager(out LobbyManager lobbyManager)
        {
            lobbyManager = LobbyManager.Instance;

            if (!IsServer) return false;

            if (lobbyManager == null)
            {
                Debug.LogError("[SERVER] LobbyManager.Instance is NULL");
                return false;
            }
Debug.Log("[CLIENT][FLOW] PlayerNetwork SUCCESS");
            return true;
        }
    }
}
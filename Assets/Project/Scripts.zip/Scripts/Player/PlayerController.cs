using UnityEngine;
using System;
using System.Collections.Generic;
using Game.Core;
using Unity.Netcode;
using Multiplayer;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(PlayerModel))]
[RequireComponent(typeof(PlayerView))]
public sealed class PlayerController : NetworkBehaviour, IPlayerController, IPlayerEntity
{
    [Serializable]
    private struct PredictedFrameState
    {
        public Vector3 position;
        public Vector2 velocity;
        public float runSpeed;
        public PlayerState state;
        public bool isGrounded;
        public int jumpsLeft;
        public bool isWallClinging;
        public int wallClingEndTick;
        public float wallClingNormalX;
        public int slideEndTick;
        public float gravityScale;
    }

    [Header("Prediction / Validation")]
    // MODIFIED: production-style correction thresholds. Reconciliation should be rare.
    [SerializeField] private float reconciliationThreshold = 2f;
    [SerializeField] private float correctionLerpSpeed = 10f;
    [SerializeField] private float validationPositionTolerance = 0.35f;
    [SerializeField] private float validationVerticalTolerance = 1.5f;

    // ADDED: bounded history for prediction / replay.
    private const int BufferHistorySize = 128;

    private Rigidbody2D rb;
    private PlayerModel model;
    private PlayerView view;
    private BoxCollider2D boxCollider;
    private CapsuleCollider2D capsuleCollider;
    private Vector2 colliderOriginalSize;
    private Vector2 colliderOriginalOffset;
    private bool colliderCached;
    private float originalGravityScale;
    private int climbableWallLayer;

    private PowerUpController powerUpController;
    private IInputSource inputSource;

    // ADDED: owner prediction buffers.
    private readonly Dictionary<int, PlayerInputData> inputBuffer = new();
    private readonly Dictionary<int, Vector3> predictedStateBuffer = new();
    private readonly Dictionary<int, PredictedFrameState> predictedFrameBuffer = new();

    // ADDED: server validation buffer.
    private readonly Dictionary<int, Vector3> stateBuffer = new();
    private bool serverValidationInitialized;
    private int lastValidatedTick = -1;
    private Vector3 lastValidatedPosition;
    private int serverLastGroundedTick = int.MinValue / 4;
    private int serverAirJumpsUsed;

    // ADDED: instant owner input capture between Update and FixedUpdate.
    private bool pendingJumpInput;

    // ADDED: rare smooth correction only after major desync.
    private bool hasSmoothCorrection;
    private Vector3 smoothCorrectionTarget;
    private bool isReplayingInputs;

    public event Action OnJump;
    public event Action OnLand;
    public event Action<PlayerState> OnStateChanged;

    public Transform Transform => transform;
    public Rigidbody2D Rigidbody => rb;
    public IReadOnlyDictionary<int, PlayerInputData> InputBuffer => inputBuffer;

    // MODIFIED: server-only write so non-owners still get jump animation edges.
    private readonly NetworkVariable<bool> isJumping = new(
        false,
        NetworkVariableReadPermission.Everyone,
        NetworkVariableWritePermission.Server
    );
    private bool wasJumping;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        model = GetComponent<PlayerModel>();
        view = GetComponent<PlayerView>();
        powerUpController = GetComponent<PowerUpController>();
        inputSource = GetComponent<IInputSource>();

        CacheCollider();
        originalGravityScale = rb.gravityScale;
        climbableWallLayer = LayerMask.NameToLayer("ClimbableWall");

        if (inputSource == null) Debug.LogError($"[PlayerController] No IInputSource on {name}");
        if (model == null) Debug.LogError($"[PlayerController] No PlayerModel on {name}");
        if (view == null) Debug.LogError($"[PlayerController] No PlayerView on {name}");

        model.MaxRunSpeed = model.BaseMaxRunSpeed;

        if (model.GroundCheck == null)
        {
            var go = new GameObject("GroundCheck");
            go.transform.SetParent(transform);
            go.transform.localPosition = new Vector3(0f, -0.5f, 0f);
            model.GroundCheck = go.transform;
        }
    }

    private void Start()
    {
        model.JumpsLeft = model.MaxJumps;
        UpdateState(PlayerState.Running);
    }

    private void OnEnable()
    {
        lastPosition = transform.position;
    }

    public override void OnNetworkSpawn()
    {
        Debug.Log($"Player Spawned | Owner: {IsOwner} | ClientId: {OwnerClientId}");

        if (IsServer)
        {
            RaceManager.Instance?.RegisterPlayer(this, GetComponent<IPlayerEntity>());
            lastValidatedPosition = transform.position;
            serverValidationInitialized = true;
        }

        if (!IsOwner)
        {
            isJumping.OnValueChanged += OnJumpStateChanged;
        }

        // MODIFIED: owner-authoritative NetworkTransform should remain enabled.
        // REMOVED: disabling NetworkTransform / NetworkRigidbody2D on owner.
    }

    public override void OnNetworkDespawn()
    {
        if (!IsOwner)
        {
            isJumping.OnValueChanged -= OnJumpStateChanged;
        }
    }

    private void OnJumpStateChanged(bool previous, bool current)
    {
        if (!IsOwner && current && !previous)
        {
            view?.TriggerJump();
        }
    }

    private void Update()
    {
        if (IsOwner)
        {
            ApplySmoothCorrection();
        }

        UpdateAnimator();

        if (!IsOwner) return;
        if (RaceManager.Instance == null) return;

        if (!RaceManager.Instance.CanMove())
        {
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
            return;
        }

        if (inputSource != null)
        {
            // MODIFIED: jump is handled instantly on the owner. No waiting for server.
            if (inputSource.JumpPressed)
            {
                pendingJumpInput = true;
                HandleImmediateJumpInput(GetCurrentTick());
            }

            if (inputSource.SlidePressed)
            {
                int currentTick = GetCurrentTick();

                if (model.IsGrounded)
                    TryStartSlide(currentTick);
                else
                    TryPerformAirDive();
            }

            if (inputSource.PowerUpPressed)
                powerUpController?.Activate();
        }

        if (wasJumping && isJumping.Value)
        {
            ResetJumpServerRpc();
        }

        wasJumping = isJumping.Value;
    }

    private void FixedUpdate()
    {
        if (!IsOwner) return;
        if (TickManager.Instance == null) return;

        int currentTick = GetCurrentTick();

        HandleGround(currentTick);
        TryConsumeBufferedJump(currentTick);

        if (model.HasFinishedRace)
        {
            if (Mathf.Abs(rb.linearVelocity.x) <= model.IdleSpeedThreshold)
            {
                rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
                UpdateState(PlayerState.Idle);
            }
            return;
        }

        if (RaceManager.Instance == null || !RaceManager.Instance.CanMove())
        {
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
            return;
        }

        PlayerInputData input = new PlayerInputData(
            inputSource != null ? inputSource.Horizontal : 0f,
            pendingJumpInput,
            currentTick
        );

        inputBuffer[currentTick] = input;
        pendingJumpInput = false;

        ApplyPredictedMovement(currentTick);
        predictedStateBuffer[currentTick] = transform.position;
        predictedFrameBuffer[currentTick] = CaptureFrameState();
        TrimBuffers(currentTick);

        if (IsServer)
        {
            ValidateOwnerState(input, rb.position, rb.linearVelocity, model.IsGrounded);
        }
        else
        {
            SubmitInputServerRpc(input, rb.position, rb.linearVelocity, model.IsGrounded);
        }
    }

    [ServerRpc]
    private void SubmitInputServerRpc(PlayerInputData input, Vector2 reportedPosition, Vector2 reportedVelocity, bool reportedGrounded)
    {
        // REMOVED: server-side movement simulation.
        // MODIFIED: server only validates the owner-reported state.
        ValidateOwnerState(input, reportedPosition, reportedVelocity, reportedGrounded);
    }

    [ServerRpc]
    private void ResetJumpServerRpc()
    {
        isJumping.Value = false;
    }

    [ServerRpc]
    private void SetJumpServerRpc()
    {
        isJumping.Value = true;
    }

    [ClientRpc]
    private void SendStateClientRpc(int tick, Vector3 serverPosition, ClientRpcParams clientRpcParams = default)
    {
        if (!IsOwner) return;

        if (!predictedStateBuffer.TryGetValue(tick, out Vector3 predictedPosition))
            return;

        // MODIFIED: only reconcile on true desync, not tiny frame-to-frame drift.
        if ((serverPosition - predictedPosition).sqrMagnitude <= reconciliationThreshold * reconciliationThreshold)
            return;

        Reconcile(tick, serverPosition);
    }

    // ADDED: server validation path. No physics simulation, only sanity checks.
    private void ValidateOwnerState(PlayerInputData input, Vector2 reportedPosition, Vector2 reportedVelocity, bool reportedGrounded)
    {
        int tickDelta = lastValidatedTick < 0 ? 1 : Mathf.Max(1, input.tick - lastValidatedTick);
        float fixedDelta = Time.fixedDeltaTime;

        if (!serverValidationInitialized)
        {
            serverValidationInitialized = true;
            lastValidatedTick = input.tick;
            lastValidatedPosition = reportedPosition;
            serverLastGroundedTick = reportedGrounded ? input.tick : int.MinValue / 4;
            serverAirJumpsUsed = 0;
            stateBuffer[input.tick] = reportedPosition;
            return;
        }

        if (reportedGrounded)
        {
            serverLastGroundedTick = input.tick;
            serverAirJumpsUsed = 0;
        }

        float maxHorizontalDelta = (model.MaxRunSpeed * fixedDelta * tickDelta) + validationPositionTolerance;
        float maxVerticalDelta = (Mathf.Max(model.JumpVelocity, Mathf.Max(model.WallJumpUpVelocity, model.AirDiveDownVelocity)) * fixedDelta * tickDelta)
            + validationVerticalTolerance;

        float horizontalDelta = Mathf.Abs(reportedPosition.x - lastValidatedPosition.x);
        float verticalDelta = Mathf.Abs(reportedPosition.y - lastValidatedPosition.y);

        bool invalidHorizontal = horizontalDelta > maxHorizontalDelta;
        bool invalidVertical = verticalDelta > maxVerticalDelta;
        bool invalidJump = false;

        if (input.jump)
        {
            int ticksSinceGrounded = input.tick - serverLastGroundedTick;
            bool canGroundJump = reportedGrounded || ticksSinceGrounded <= SecondsToTicks(model.CoyoteTime);
            bool canAirJump = serverAirJumpsUsed < Mathf.Max(0, model.MaxJumps - 1);

            if (!canGroundJump && !canAirJump)
            {
                invalidJump = true;
            }
            else if (!canGroundJump)
            {
                serverAirJumpsUsed++;
            }
        }

        if (invalidHorizontal || invalidVertical || invalidJump)
        {
            ClientRpcParams clientRpcParams = new ClientRpcParams
            {
                Send = new ClientRpcSendParams
                {
                    TargetClientIds = new[] { OwnerClientId }
                }
            };

            SendStateClientRpc(input.tick, lastValidatedPosition, clientRpcParams);
            return;
        }

        lastValidatedTick = input.tick;
        lastValidatedPosition = reportedPosition;
        stateBuffer[input.tick] = reportedPosition;
        TrimStateBuffer(input.tick);

        if (input.jump && IsServer)
        {
            isJumping.Value = true;
        }
    }

    // MODIFIED: reconciliation restores a buffered simulation snapshot, then replays later inputs.
    private void Reconcile(int fromTick, Vector3 serverPosition)
    {
        int currentTick = GetCurrentTick();
        Vector3 preCorrectionPosition = transform.position;

        if (predictedFrameBuffer.TryGetValue(fromTick, out PredictedFrameState baseState))
        {
            RestoreFrameState(baseState, serverPosition);
        }
        else
        {
            rb.position = serverPosition;
            transform.position = new Vector3(serverPosition.x, serverPosition.y, transform.position.z);
        }

        isReplayingInputs = true;

        for (int tick = fromTick + 1; tick <= currentTick; tick++)
        {
            if (!inputBuffer.TryGetValue(tick, out PlayerInputData replayInput))
                continue;

            if (replayInput.jump)
            {
                model.LastJumpPressedTick = tick;
            }

            HandleGround(tick);
            TryConsumeBufferedJump(tick);
            ApplyPredictedMovement(tick);

            predictedStateBuffer[tick] = transform.position;
            predictedFrameBuffer[tick] = CaptureFrameState();
        }

        isReplayingInputs = false;

        Vector3 correctedPosition = transform.position;
        transform.position = Vector3.Lerp(preCorrectionPosition, correctedPosition, 0.25f);
        rb.position = new Vector2(transform.position.x, transform.position.y);
        smoothCorrectionTarget = correctedPosition;
        hasSmoothCorrection = true;
    }

    private void ApplySmoothCorrection()
    {
        if (!hasSmoothCorrection) return;

        Vector3 smoothed = Vector3.Lerp(
            transform.position,
            smoothCorrectionTarget,
            correctionLerpSpeed * Time.deltaTime
        );

        transform.position = smoothed;
        rb.position = new Vector2(smoothed.x, smoothed.y);

        if ((smoothCorrectionTarget - transform.position).sqrMagnitude < 0.0004f)
        {
            transform.position = smoothCorrectionTarget;
            rb.position = new Vector2(smoothCorrectionTarget.x, smoothCorrectionTarget.y);
            hasSmoothCorrection = false;
        }
    }

    // MODIFIED: tick-based simulation only. No Time.time in prediction logic.
    private void ApplyPredictedMovement(int currentTick)
    {
        if (model.State == PlayerState.WallCling)
        {
            model.CurrentRunSpeed = 0f;
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);

            if (currentTick >= model.WallClingEndTick)
                EndWallCling();

            return;
        }

        if (model.State == PlayerState.Sliding)
        {
            model.CurrentRunSpeed = Mathf.MoveTowards(
                model.CurrentRunSpeed,
                0f,
                model.SlideSpeedDecay * Time.fixedDeltaTime
            );

            rb.linearVelocity = new Vector2(model.CurrentRunSpeed, rb.linearVelocity.y);

            if (currentTick >= model.SlideEndTick || !model.IsGrounded)
                EndSlide();

            return;
        }

        model.CurrentRunSpeed = Mathf.MoveTowards(
            model.CurrentRunSpeed,
            model.MaxRunSpeed,
            model.AccelerationRate * Time.fixedDeltaTime
        );

        rb.linearVelocity = new Vector2(model.CurrentRunSpeed, rb.linearVelocity.y);

        if (!model.IsGrounded && rb.linearVelocity.y < -0.1f && model.State != PlayerState.Falling)
            UpdateState(PlayerState.Falling);
    }

    // MODIFIED: client is the source of truth for grounded state during prediction.
    private void HandleGround(int currentTick)
    {
        bool wasGrounded = model.IsGrounded;

        if (currentTick < model.NextAllowedGroundCheckTick)
        {
            model.IsGrounded = false;
            return;
        }

        model.IsGrounded = Physics2D.OverlapBox(
            model.GroundCheck.position,
            model.GroundCheckSize,
            0f,
            model.GroundLayer
        );

        if (model.IsGrounded)
        {
            model.LastGroundedTick = currentTick;
            model.JumpsLeft = model.MaxJumps;

            if (!wasGrounded)
            {
                OnLand?.Invoke();
                UpdateState(PlayerState.Running);
            }
        }
    }

    // ADDED: immediate owner jump feel while still buffering by tick.
    private void HandleImmediateJumpInput(int currentTick)
    {
        if (model.IsWallClinging)
        {
            TryPerformWallJump(currentTick);
            return;
        }

        model.LastJumpPressedTick = currentTick;
        TryConsumeBufferedJump(currentTick);
    }

    private void TryConsumeBufferedJump(int currentTick)
    {
        if (model.IsWallClinging) return;
        if (currentTick - model.LastJumpPressedTick > SecondsToTicks(model.JumpBufferTime)) return;

        bool hasCoyoteWindow = currentTick - model.LastGroundedTick <= SecondsToTicks(model.CoyoteTime);

        if (model.IsGrounded || hasCoyoteWindow || model.JumpsLeft > 0)
        {
            TryPerformJump(currentTick);
            model.LastJumpPressedTick = int.MinValue / 4;
        }
    }

    private void TryPerformJump(int currentTick)
    {
        if (!model.ControlEnabled) return;
        if (model.State == PlayerState.Sliding) EndSlide();

        model.CurrentRunSpeed *= model.JumpHorizontalSpeedMultiplier;
        rb.linearVelocity = new Vector2(model.CurrentRunSpeed, model.JumpVelocity);

        model.JumpsLeft = Mathf.Max(0, model.JumpsLeft - 1);
        model.NextAllowedGroundCheckTick = currentTick + SecondsToTicks(model.GroundGraceDelay);

        view?.UpdateMovement(model.CurrentRunSpeed / model.MaxRunSpeed, false);

        if (!isReplayingInputs)
        {
            view?.TriggerJump();
            OnJump?.Invoke();

            if (IsServer)
                isJumping.Value = true;
            else
                SetJumpServerRpc();
        }

        UpdateState(PlayerState.Jumping);
    }

    private Vector3 lastPosition;

    private void UpdateAnimator()
    {
        float normalizedSpeed;

        if (IsOwner)
        {
            normalizedSpeed = model.CurrentRunSpeed / model.MaxRunSpeed;
            view?.UpdateMovement(normalizedSpeed, model.IsGrounded);
            return;
        }

        float delta = (transform.position - lastPosition).magnitude;
        float speed = delta / Mathf.Max(Time.deltaTime, 0.0001f);
        normalizedSpeed = Mathf.Clamp01(speed / model.MaxRunSpeed);
        bool isGrounded = Mathf.Abs(rb.linearVelocity.y) < 0.1f;
        view?.UpdateMovement(normalizedSpeed, isGrounded);
        lastPosition = transform.position;
    }

    private void UpdateState(PlayerState newState)
    {
        if (model.State == newState) return;
        model.State = newState;
        OnStateChanged?.Invoke(newState);
    }

    public void Kill() => gameObject.SetActive(false);

    public void EnableControl()
    {
        model.ControlEnabled = true;
        UpdateState(PlayerState.Running);
    }

    public void DisableControl()
    {
        model.ControlEnabled = false;
        rb.linearVelocity = Vector2.zero;
        view?.SetSpeed(0f);
        UpdateState(PlayerState.Disabled);
    }

    public void ResetVelocity() => rb.linearVelocity = Vector2.zero;
    public void ResetRunSpeed() => model.CurrentRunSpeed = 0f;

    public void ModifyMaxRunSpeed(float multiplier) =>
        model.MaxRunSpeed = model.BaseMaxRunSpeed * multiplier;

    public void ResetMaxRunSpeed() =>
        model.MaxRunSpeed = model.BaseMaxRunSpeed;

    public void ForceJump() => TryPerformJump(GetCurrentTick());

    public void OnFinishRace()
    {
        model.HasFinishedRace = true;
        model.ControlEnabled = false;
        model.CurrentRunSpeed = 0f;
        RestoreCollider();
        EndWallCling();
        UpdateState(PlayerState.Disabled);
    }

    public bool IsTargetable
    {
        get
        {
            if (model.HasFinishedRace) return false;
            if (!gameObject.activeInHierarchy) return false;
            var health = GetComponent<PlayerHealth>();
            if (health == null || health.IsInvincible) return false;
            return rb.simulated;
        }
    }

    private void TryStartSlide(int currentTick)
    {
        if (!model.ControlEnabled) return;
        if (!model.IsGrounded) return;
        if (model.State == PlayerState.Sliding) return;
        if (!colliderCached) return;

        ApplySlideCollider();
        model.CurrentRunSpeed = Mathf.Min(
            model.CurrentRunSpeed,
            model.MaxRunSpeed * model.SlideStartSpeedMultiplier
        );
        model.SlideEndTick = currentTick + SecondsToTicks(model.SlideDuration);
        UpdateState(PlayerState.Sliding);
    }

    private void EndSlide()
    {
        RestoreCollider();
        UpdateState(model.IsGrounded ? PlayerState.Running : PlayerState.Falling);
    }

    private void TryPerformAirDive()
    {
        if (!model.ControlEnabled) return;
        if (model.IsGrounded) return;
        if (model.State == PlayerState.WallCling) return;
        if (model.AirDiveDownVelocity <= 0f) return;

        rb.linearVelocity = new Vector2(rb.linearVelocity.x, -model.AirDiveDownVelocity);
        UpdateState(PlayerState.Falling);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!model.ControlEnabled || model.HasFinishedRace) return;
        if (model.IsGrounded) return;
        if (!IsClingableWall(collision.collider)) return;

        foreach (var contact in collision.contacts)
        {
            if (Mathf.Abs(contact.normal.x) <= 0.7f) continue;
            TryStartWallCling(contact.normal.x, GetCurrentTick());
            break;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (!model.IsWallClinging) return;
        if (IsClingableWall(collision.collider)) EndWallCling();
    }

    private bool IsClingableWall(Collider2D collider2D)
    {
        if (collider2D == null) return false;
        if (collider2D.CompareTag("Wall")) return true;
        if (climbableWallLayer != -1 && collider2D.gameObject.layer == climbableWallLayer) return true;
        return false;
    }

    private void TryStartWallCling(float wallNormalX, int currentTick)
    {
        if (model.IsWallClinging) return;

        model.IsWallClinging = true;
        model.WallClingNormalX = Mathf.Sign(wallNormalX);
        model.WallClingEndTick = currentTick + SecondsToTicks(model.WallClingDuration);
        rb.gravityScale = model.WallClingGravityScale;
        rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        UpdateState(PlayerState.WallCling);
    }

    private void EndWallCling()
    {
        if (!model.IsWallClinging) return;
        model.IsWallClinging = false;
        rb.gravityScale = originalGravityScale;
        UpdateState(model.IsGrounded ? PlayerState.Running : PlayerState.Falling);
    }

    private void TryPerformWallJump(int currentTick)
    {
        if (!model.ControlEnabled) return;
        if (!model.IsWallClinging) return;

        model.CurrentRunSpeed *= model.JumpHorizontalSpeedMultiplier;

        float away = model.WallClingNormalX == 0f ? 1f : model.WallClingNormalX;
        rb.linearVelocity = new Vector2(
            away * model.WallJumpHorizontalVelocity,
            model.WallJumpUpVelocity
        );

        model.NextAllowedGroundCheckTick = currentTick + SecondsToTicks(model.GroundGraceDelay);
        model.WallClingEndTick = currentTick;
        EndWallCling();

        if (!isReplayingInputs)
        {
            view?.TriggerJump();
            OnJump?.Invoke();

            if (IsServer)
                isJumping.Value = true;
            else
                SetJumpServerRpc();
        }

        UpdateState(PlayerState.Jumping);
    }

    private void CacheCollider()
    {
        if (colliderCached) return;

        boxCollider = GetComponent<BoxCollider2D>();
        capsuleCollider = GetComponent<CapsuleCollider2D>();

        if (boxCollider != null)
        {
            colliderOriginalSize = boxCollider.size;
            colliderOriginalOffset = boxCollider.offset;
            colliderCached = true;
            return;
        }

        if (capsuleCollider != null)
        {
            colliderOriginalSize = capsuleCollider.size;
            colliderOriginalOffset = capsuleCollider.offset;
            colliderCached = true;
            return;
        }

        Debug.LogWarning($"[PlayerController] No collider found on {name}. Slide disabled.");
    }

    private void ApplySlideCollider()
    {
        float heightMultiplier = model.SlideColliderHeightMultiplier;

        if (boxCollider != null)
        {
            float newHeight = colliderOriginalSize.y * heightMultiplier;
            float delta = (colliderOriginalSize.y - newHeight) * 0.5f;
            boxCollider.size = new Vector2(colliderOriginalSize.x, newHeight);
            boxCollider.offset = new Vector2(colliderOriginalOffset.x, colliderOriginalOffset.y - delta);
            return;
        }

        if (capsuleCollider != null)
        {
            float newHeight = colliderOriginalSize.y * heightMultiplier;
            float delta = (colliderOriginalSize.y - newHeight) * 0.5f;
            capsuleCollider.size = new Vector2(colliderOriginalSize.x, newHeight);
            capsuleCollider.offset = new Vector2(colliderOriginalOffset.x, colliderOriginalOffset.y - delta);
        }
    }

    private void RestoreCollider()
    {
        if (boxCollider != null)
        {
            boxCollider.size = colliderOriginalSize;
            boxCollider.offset = colliderOriginalOffset;
            return;
        }

        if (capsuleCollider != null)
        {
            capsuleCollider.size = colliderOriginalSize;
            capsuleCollider.offset = colliderOriginalOffset;
        }
    }

    private PredictedFrameState CaptureFrameState()
    {
        return new PredictedFrameState
        {
            position = transform.position,
            velocity = rb.linearVelocity,
            runSpeed = model.CurrentRunSpeed,
            state = model.State,
            isGrounded = model.IsGrounded,
            jumpsLeft = model.JumpsLeft,
            isWallClinging = model.IsWallClinging,
            wallClingEndTick = model.WallClingEndTick,
            wallClingNormalX = model.WallClingNormalX,
            slideEndTick = model.SlideEndTick,
            gravityScale = rb.gravityScale
        };
    }

    private void RestoreFrameState(PredictedFrameState frameState, Vector3 authoritativePosition)
    {
        transform.position = authoritativePosition;
        rb.position = new Vector2(authoritativePosition.x, authoritativePosition.y);
        rb.linearVelocity = frameState.velocity;
        rb.gravityScale = frameState.gravityScale;
        model.CurrentRunSpeed = frameState.runSpeed;
        model.State = frameState.state;
        model.IsGrounded = frameState.isGrounded;
        model.JumpsLeft = frameState.jumpsLeft;
        model.IsWallClinging = frameState.isWallClinging;
        model.WallClingEndTick = frameState.wallClingEndTick;
        model.WallClingNormalX = frameState.wallClingNormalX;
        model.SlideEndTick = frameState.slideEndTick;
    }

    private void TrimBuffers(int currentTick)
    {
        int expiredTick = currentTick - BufferHistorySize;
        inputBuffer.Remove(expiredTick);
        predictedStateBuffer.Remove(expiredTick);
        predictedFrameBuffer.Remove(expiredTick);
        stateBuffer.Remove(expiredTick);
    }

    private void TrimStateBuffer(int currentTick)
    {
        int expiredTick = currentTick - BufferHistorySize;
        stateBuffer.Remove(expiredTick);
    }

    private int GetCurrentTick()
    {
        return TickManager.Instance != null ? TickManager.Instance.CurrentTick : 0;
    }

    private int SecondsToTicks(float seconds)
    {
        int tickRate = TickManager.Instance != null ? TickManager.Instance.TickRate : 60;
        return Mathf.Max(1, Mathf.CeilToInt(seconds * tickRate));
    }

#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {
        var currentModel = model != null ? model : GetComponent<PlayerModel>();
        if (currentModel == null || currentModel.GroundCheck == null) return;

        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(
            currentModel.GroundCheck.position,
            new Vector3(currentModel.GroundCheckSize.x, currentModel.GroundCheckSize.y, 0.1f)
        );
    }
#endif
}

using UnityEngine;
using Game.Core;

[CreateAssetMenu(menuName = "PowerUps/Shield")]
public sealed class ShieldPowerUpDefinition : PowerUpDefinition
{
    public GameObject shieldVisualPrefab;

    public override IPowerUpEffect CreateEffect() => new Effect(this);

    private sealed class Effect : IPowerUpEffect
    {
        private readonly ShieldPowerUpDefinition def;
        private GameObject visual;
        private PowerUpContext context;

        public Effect(ShieldPowerUpDefinition def) { this.def = def; }

        public void Activate(PowerUpContext ctx)
        {
            context = ctx;
            ctx.Health.SetInvincible(true);

            // ✅ Pool instead of Instantiate
            // VFXPool handles the shield visual lifecycle — no Destroy on Deactivate
            if (VFXPool.Instance != null)
            {
                visual = VFXPool.Instance.GetShieldVisual(
                    ctx.PlayerTransform.position,
                    ctx.PlayerTransform
                );
            }
            else
            {
                visual = Object.Instantiate(
                    def.shieldVisualPrefab,
                    ctx.PlayerTransform.position,
                    Quaternion.identity,
                    ctx.PlayerTransform
                );
            }
        }

        public void Deactivate()
        {
            if (context != null)
                context.Health.SetInvincible(false);

            // ✅ Return to pool instead of Destroy
            if (visual != null)
            {
                if (VFXPool.Instance != null)
                    VFXPool.Instance.ReturnShieldVisual(visual);
                else
                    Object.Destroy(visual);

                visual = null;
            }
        }
    }
}
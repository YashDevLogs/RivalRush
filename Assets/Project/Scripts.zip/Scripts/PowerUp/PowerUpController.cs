using UnityEngine;
using System;
using Game.Core;

[RequireComponent(typeof(PlayerHealth))]
public sealed class PowerUpController : MonoBehaviour
{
    private PowerUpDefinition heldDefinition;
    private IPowerUpEffect activeEffect;
    private PowerUpContext context;
    private PowerUpId activePowerUpId = PowerUpId.None;

    // Replaces StartCoroutine(ExpireAfter(duration))
    // Zero allocation per activation
    private float effectTimeRemaining = -1f;

    public bool HasPowerUp => heldDefinition != null;
    public event Action<PowerUpId> OnPowerUpChanged;

    [SerializeField] private PowerUpAssets sharedAssets;
    public PowerUpDefinition CurrentDefinition => heldDefinition;

    private void Awake()
    {
        context = new PowerUpContext(
            GetComponent<IPlayerController>(),
            GetComponent<IHealth>(),
            transform,
            this,
            sharedAssets
        );
    }

    private void Update()
    {
        if (effectTimeRemaining <= 0f) return;

        effectTimeRemaining -= Time.deltaTime;

        if (effectTimeRemaining <= 0f)
        {
            effectTimeRemaining = -1f;
            DeactivateCurrentEffect();
        }
    }

    public void Pickup(PowerUpDefinition definition)
    {
        if (HasPowerUp) return;
        heldDefinition = definition;
        GameEvents.RaisePowerUpPicked(definition.id);
        OnPowerUpChanged?.Invoke(definition.id);
    }

    public void Activate()
    {
        if (!HasPowerUp) return;

        DeactivateCurrentEffect();
        effectTimeRemaining = -1f;

        activeEffect = heldDefinition.CreateEffect();
        activePowerUpId = heldDefinition.id;
        activeEffect.Activate(context);
        GameEvents.RaisePowerUpActivated(activePowerUpId);
        OnPowerUpChanged?.Invoke(PowerUpId.None);

        if (heldDefinition.duration > 0f)
            effectTimeRemaining = heldDefinition.duration;

        heldDefinition = null;
    }

    public void ForceClear()
    {
        DeactivateCurrentEffect();
        effectTimeRemaining = -1f;
        heldDefinition = null;
    }

    public void ClearActiveEffects()
    {
        DeactivateCurrentEffect();
        effectTimeRemaining = -1f;
    }

    private void DeactivateCurrentEffect()
    {
        if (activeEffect == null) return;
        activeEffect.Deactivate();
        activeEffect = null;

        if (activePowerUpId != PowerUpId.None)
            GameEvents.RaisePowerUpExpired(activePowerUpId);

        activePowerUpId = PowerUpId.None;
    }
}

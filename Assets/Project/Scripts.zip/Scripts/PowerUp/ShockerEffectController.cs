using UnityEngine;
using Game.Core;

public sealed class ShockerEffectController : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] private float lifetime = 1f;
    [SerializeField] private float radius = 2.2f;

    private Transform followTarget;
    private IPlayerEntity ownerEntity;
    private bool damageApplied;
    private float lifeTimer;

    public void Initialize(Transform owner)
    {
        followTarget = owner;
        ownerEntity = owner != null ? owner.GetComponent<IPlayerEntity>() : null;
        damageApplied = false;
        lifeTimer = 0f;

        foreach (var ps in GetComponentsInChildren<ParticleSystem>(true))
        {
            ps.Clear(true);
            ps.Play(true);
        }

        ApplyDamage();
    }

    private void Update()
    {
        lifeTimer += Time.deltaTime;
        if (lifeTimer >= lifetime)
            ProjectilePool.Instance?.ReturnShocker(this);
    }

    private void LateUpdate()
    {
        if (followTarget != null)
            transform.position = followTarget.position;
    }

    private void ApplyDamage()
    {
        if (damageApplied) return;
        damageApplied = true;

        foreach (var hit in Physics2D.OverlapCircleAll(transform.position, radius))
        {
            if (!hit.TryGetComponent<IPlayerEntity>(out var victim)) continue;
            if (victim == ownerEntity) continue;
            if (!victim.IsTargetable) continue;

            if (hit.TryGetComponent<IHealth>(out var health))
            {
                health.TakeDamage(1);
                GameEvents.RaisePlayerKilled(
                    new KillEventData(ownerEntity, victim, PowerUpId.Shocker));
            }
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Game.Systems
{
    public class LobbyUI : MonoBehaviour
    {
        [Header("UI References")]
        [SerializeField] private GameObject lobbyPanel;
        [SerializeField] private Transform playerListParent;
        [SerializeField] private PlayerSlotUI playerSlotPrefab;

        private readonly List<PlayerSlotUI> slotPool = new List<PlayerSlotUI>();

        private NetworkList<LobbyPlayerData> subscribedList;
        private bool isReady;

        private void Awake()
        {
            for (int i = 0; i < LobbyManager.MaxPlayers; i++)
            {
                var slot = Instantiate(playerSlotPrefab, playerListParent);
                slot.gameObject.SetActive(false);
                slotPool.Add(slot);
            }
        }

        private void OnEnable()
        {
            ReinitializeLobbyUI();
        }

        private void OnDisable()
        {
            if (subscribedList != null)
            {
                subscribedList.OnListChanged -= OnLobbyUpdated;
                subscribedList = null;
            }
        }

        private void ReinitializeLobbyUI()
        {
            StopAllCoroutines();
            StartCoroutine(WaitForLobby());
        }

        private IEnumerator WaitForLobby()
        {
            while (LobbyManager.Instance == null || !LobbyManager.Instance.IsSpawned)
            {
                yield return null;
            }

            isReady = false;

            if (subscribedList != null && subscribedList != LobbyManager.Instance.Players)
            {
                subscribedList.OnListChanged -= OnLobbyUpdated;
            }

            subscribedList = LobbyManager.Instance.Players;
            subscribedList.OnListChanged -= OnLobbyUpdated;
            subscribedList.OnListChanged += OnLobbyUpdated;

            lobbyPanel.SetActive(true);
            RefreshUI();
        }

        private void OnLobbyUpdated(NetworkListEvent<LobbyPlayerData> changeEvent)
        {
            RefreshUI();
        }

        private void RefreshUI()
        {
            if (LobbyManager.Instance == null || LobbyManager.Instance.Players == null)
            {
                Debug.LogError("[LobbyUI] RefreshUI failed. LobbyManager is unavailable.");
                return;
            }

            foreach (var slot in slotPool)
            {
                slot.gameObject.SetActive(false);
            }

            int slotIndex = 0;
            foreach (var player in LobbyManager.Instance.Players)
            {
                if (player.IsAI)
                {
                    continue;
                }

                if (slotIndex >= slotPool.Count)
                {
                    break;
                }

                var slot = slotPool[slotIndex];
                slot.gameObject.SetActive(true);
                slot.Setup(player.PlayerName.ToString(), player.IsReady);
                slotIndex++;
            }
        }

        public void OnCreateLobby()
        {
            if (LobbyManager.IsShuttingDown)
            {
                Debug.LogWarning("[UI] Ignored input during shutdown");
                return;
            }

            SessionManager.Instance.CreateSession();
        }

        public void OnJoinLobby()
        {
            if (LobbyManager.IsShuttingDown)
            {
                Debug.LogWarning("[UI] Ignored input during shutdown");
                return;
            }

            SessionManager.Instance.JoinSession();
        }

        public void OnReadyClicked()
        {
            Debug.Log("[CLIENT][FLOW] OnReadyClicked START");
            if (LobbyManager.IsShuttingDown)
            {
                Debug.LogWarning("[UI] Ignored input during shutdown");
                return;
            }

            if (!TryGetLocalPlayerNetwork(out var playerNetwork))
            {
                return;
            }

            Debug.Log($"[CLIENT] IsListening: {NetworkManager.Singleton.IsListening}");
            isReady = !isReady;
            playerNetwork.SendReady(isReady);
        }

        public void OnLeaveLobbyClicked()
        {
            if (LobbyManager.IsShuttingDown)
            {
                Debug.LogWarning("[UI] Ignored input during shutdown");
                return;
            }

            if (NetworkManager.Singleton == null || !NetworkManager.Singleton.IsListening)
            {
                SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
                return;
            }

            if (!TryGetLocalPlayerNetwork(out var playerNetwork))
            {
                return;
            }

            Debug.Log($"[CLIENT] IsListening: {NetworkManager.Singleton.IsListening}");
            playerNetwork.LeaveLobby();
        }

        private static bool TryGetLocalPlayerNetwork(out PlayerNetwork playerNetwork)
        {
            playerNetwork = null;

            if (NetworkManager.Singleton == null)
            {
                Debug.LogError("[CLIENT] NetworkManager is NULL");
                return false;
            }

            Debug.Log($"[CLIENT] IsListening: {NetworkManager.Singleton.IsListening}");

            if (!NetworkManager.Singleton.IsListening)
            {
                Debug.LogError("[CLIENT] NetworkManager is NOT listening");
                return false;
            }

            var localClient = NetworkManager.Singleton.LocalClient;
            if (localClient == null)
            {
                Debug.LogError("[CLIENT] LocalClient is NULL");
                return false;
            }

            var localPlayer = localClient.PlayerObject;

            // 🔥 CRITICAL DEBUG BLOCK
            Debug.Log($"[CLIENT][DEBUG] PlayerObject: {localPlayer}");
            Debug.Log($"[CLIENT][DEBUG] IsSpawned: {localPlayer?.IsSpawned}");
            Debug.Log($"[CLIENT][DEBUG] IsOwner: {localPlayer?.IsOwner}");
            Debug.Log($"[CLIENT][DEBUG] NetId: {localPlayer?.NetworkObjectId}");

            if (localPlayer == null)
            {
                Debug.LogError("[CLIENT] LocalPlayer is NULL");
                return false;
            }

            playerNetwork = localPlayer.GetComponent<PlayerNetwork>();

            if (playerNetwork == null)
            {
                Debug.LogError("[CLIENT] PlayerNetwork missing on PlayerObject");
                return false;
            }

            Debug.Log($"[CLIENT][DEBUG] PlayerNetwork FOUND on NetId: {localPlayer.NetworkObjectId}");
            // In TryGetLocalPlayerNetwork, after getting localPlayer:
            Debug.Log($"[CLIENT] PlayerObject: {localPlayer?.name} | IsOwner: {localPlayer?.IsOwner} | NetId: {localPlayer?.NetworkObjectId}");

            return true;
        }
    }
}

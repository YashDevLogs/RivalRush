using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PlayerSlotUI : MonoBehaviour
{
    [SerializeField] private TMP_Text playerNameText;
    [SerializeField] private Image readyIndicator;

    public void Setup(string playerName, bool isReady)
    {
        playerNameText.text = playerName;

        // 🔴 Red = Not Ready
        // 🟢 Green = Ready
        readyIndicator.color = isReady ? Color.green : Color.red;
    }
}